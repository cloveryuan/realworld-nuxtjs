<template>
  <Nuxt />
</template>
